package zj.com.example.zj.news;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.os.Message;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import android.os.Handler;

public class MainActivity extends Activity {

    private List<News> newsList;
    private NewsAdapter adapter;
    private Handler handler;
    private ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newsList = new ArrayList();
        lv = (ListView) findViewById(R.id.news_lv);
        getNews();
        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if(msg.what == 1){
                    adapter = new NewsAdapter(MainActivity.this,newsList);
                    lv.setAdapter(adapter);
                    lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            News news = newsList.get(position);
                            Intent intent = new Intent(MainActivity.this,NewsDisplayActvivity.class);
                            Log.e("news.getNewsUrl()", news.getNewsUrl());
                            intent.putExtra("news_url",news.getNewsUrl());
                            startActivity(intent);
                        }
                    });
                }
            }
        };

    }

    private void getNews(){

        new Thread(new Runnable() {
            @Override
            public void run() {
            	try{

                    Document doc = Jsoup.connect("http://blog.sina.com.cn/s/articlelist_1216826604_0_1.html").get();
                    Log.e("doc",doc.toString());
                    Elements titleLinks = doc.select("div.articleCell SG_j_linedot1");    //解析来获取每条新闻的标题与链接地址
                 // Elements descLinks = doc.select("div.list-content");//解析来获取每条新闻的简介
                    Elements timeLinks = doc.select("div.atc_info");   //解析来获取每条新闻的时间与来源
                    Log.e("titleLinks.size()",Integer.toString(titleLinks.size()));
                    for(int j = 0;j < titleLinks.size();j++){
                        String title = titleLinks.get(j).select("a").text();
                        Log.e("title",title);
                        String uri = titleLinks.get(j).select("a").attr("href");
                        Log.e("uri",uri);
                   //   String desc = descLinks.get(j).select("span").text();
                        String time = timeLinks.get(j).select("span.atc_tm SG_txtc").text();
                        Log.e("time",time);
                        News news = new News(title,uri,null,time);
                        newsList.add(news);
                    }
                    
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
	}

}


